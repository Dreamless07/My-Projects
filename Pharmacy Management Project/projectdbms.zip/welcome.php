<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to our Website</title>
    <link rel="stylesheet" href="welcome1.css">
</head>
<body>
    <div class="container">
        <h3>Welcome to our Website</h3>
        <h3>PHARMACY INVENTORY MANAGMENT SYSTEM</h3>
        <p>The following website is a prototype made by AFTAB J and  MOHAMMAD SAAD KHAN of 5th sem (3rd year)  from VIJAYA VITALA INSTITUTE OF TECHNOLOGY</p> 
        <a href="register.php" class="btn">Sign Up</a>
        <a href="login.php" class="btn">Log In</a>
        <marquee> Please Sign up to register your self.</marquee>
    </div>
    
</body>
</html>
